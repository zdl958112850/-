﻿const express = require('express');
// 创建服务器
const app = express();

const compression = require('compression');
//启动中间件
app.use(compression()); // 这句代码一定要执行在静态资源之前

// 托管金泰资源
app.use(express.static('./dist')) //dist就是打包之后的文件目录
// 启动服务器
app.listen(8083, ()=> {
  console.log('web server running at http://127.0.0.1:8083')
})